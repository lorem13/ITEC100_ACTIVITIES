<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Activity Logs Page</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="js/generate_pdf.js"></script>
</head>

<style>
body{
    background-color: #3d9dd9;
}
table{
    border-collapse: collapse;
    width: 80%;
    color: white;
    font-family: monospace;
    font-size: 25px;
    text-align: left;
}
th{
    background-color: skyblue;
    color: white;
    text-align: center;
}
tr:nth-child(even){
    background-color: #2c97db;
}
button[type="submit"]{
    background: #34e1eb;
    color: black;
}
</style>

<body>
<center>
<form action="db/itec100_db.sql" method="POST">
    <button type="submit"><a href="admin_home.php">Back to home</a></button>
    <button type="submit"><a href="admin_user.php">View User Information</a></button>
    <button type="submit" name="download">Download SQL Backup</button>
    <button type="submit"><a href="admin_printPDF.php">PRINT LOGS PDF</a></button>
    <h1>ACTIVITY LOG</h1>    
</form>
</center> 
</body>
</html>
        
<?php 
session_start();

if ( isset($_SESSION['username'])) {

 ?>
<?php
		$link_address = '#'; 
        $conn = mysqli_connect("localhost", "root", "", "itec100_db");
		if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
}
        $sql2="SELECT id, username, activity, time FROM acts WHERE username='{$_SESSION['username']}'
        ORDER BY time DESC;";
        $stmt = $conn->query($sql2);
        $sql1="SELECT id, username, activity, time FROM acts ORDER BY time DESC;";
	    $stmt = $conn->query($sql1);

		echo "<br>";
		echo "<center><table>";
		
echo "<table border='3'>

<tr>

<th>Id</th>

<th>Username</th>

<th>Activity</th>

<th>Time</th>

</tr>";

if($_SESSION['username']==="ADMIN"){
	if($stmt->num_rows > 0)
    while($row = $stmt->fetch_assoc()) {

    echo "<tr>";
	echo "<td>" . $row['id'] . "</td>";
	echo "<td>" . $row['username'] . "</td>";
	echo "<td>" . $row['activity'] . "</td>";
	echo "<td>" . $row['time'] . "</td>";
	echo "</tr>";
 
}
}
	
else {
	if($stmt->num_rows > 0)
	while($row = $stmt->fetch_assoc()) {

    echo "<tr>";
	echo "<td>" . $row['id'] . "</td>";
	echo "<td>" . $row['username'] . "</td>";
	echo "<td>" . $row['activity'] . "</td>";
	echo "<td>" . $row['time'] . "</td>";
	echo "</tr>";
 
}
}
	echo "</table><center>";

}
?>