<?php
$link = mysqli_connect("localhost","root","");
mysqli_select_db($link,"itec100_db");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Create an Account</title>
</head>

<style>
body{
	margin: 0;
	padding: 0;
	background-image: url('images/bg.jpg');
	background-size: auto;
	background-position: center;
	font-family: 'Poppins', sans-serif;
}
.boxer{
	width: 420px;
	height: 460px;
	background: #7cbcd9;
	color: white;
	top: 50%;
	left: 50%;
	position: absolute;
	transform: translate(-50%, -50%);
	box-sizing: border-box;
	border-radius: 15px;
	padding: 30px 30px;
}
.boxer h1{
	margin: 0;
	padding: 0 0 20px;
	margin-top: 10px;
	text-align: center;
	color: white;
}
.boxer input{
	width: 100%;
	margin-bottom: 20px;
}
.boxer input[type="text"], input[type="email"], input[type="password"]{
	border: none;
	border-bottom: 1px solid #fff;
	background: transparent;
	outline: none;
	height: 40px;
	color: white;
	font-size: 16px;	
}
.boxer button[type="submit"]{
	border: none;
	outline: none;
	width: 300px;
	height: 40px;
	background: #42b2e3;
	color: #fff;
	font-size: 18px;
	border border-radius: 20px;
}
.boxer button[type="submit"]:hover{
	background: #008CBA;
}
</style>

<body>
<div class="boxer">
	<form action="#" method="post">
		<h1>Sign Up</h1>
			<input class="text" type="text" name="username" placeholder="Username" required= ""/>
			<input class="text email" type="email" name="email" placeholder="Email" required=""/>
			<input class = "text" type="password" id="password" name="password" placeholder = "Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required = ""/>
			<input class = "text w3lpass" type="password" id="password1" name="password" placeholder="Confirm Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required = ""/>
			<center>
				<button class="submit" type="submit" value="Sign Up" name="submit">Create Account</button>
				<br><br><a href="login.php">Login Now</a>
			</center>
	</form>	
			
<?php

if(isset($_POST['submit'])){
	
$n1=$_POST['username'];
$n2=$_POST['password'];
$n3=$_POST['email'];

$stmt="INSERT INTO users (username,password,email)VALUES('$n1','$n2','$n3')";

if(mysqli_query($link,$stmt)){
	header("Location: login.php");
}
else{
	echo "fail";
}
}
?>
</body>
</html>