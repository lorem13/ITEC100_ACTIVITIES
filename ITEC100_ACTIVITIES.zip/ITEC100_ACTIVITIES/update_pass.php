<?php 
session_start(); 
include "db_conn.php";

if (isset($_POST['uname']) && isset($_POST['password'])
    && isset($_POST['re_password'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$uname = validate($_POST['uname']);
	$pass = validate($_POST['password']);
	$re_pass = validate($_POST['re_password']);
	

	$user_data = 'uname='. $uname;
	$activity="ChangePassword";
	$duration = floor(time()/(60*5));
	srand($duration);
	date_default_timezone_set('Asia/Manila');
	$currentDate = date('Y-m-d H:i:s');
	$currentDate_timestamp = strtotime($currentDate);
	$endDate_months = strtotime("+5 minutes", $currentDate_timestamp);
	$packageEndDate = date('Y-m-d H:i:s', $endDate_months);
	$_SESSION["current"] = $currentDate;
    $_SESSION["expired"] = $packageEndDate;
	
	if (empty($uname)) {
		header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>Username is required</div></center>&$user_data");
	    exit();	
	}
	else if(empty($pass)){
        header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>Password is required</div></center>&$user_data");
	    exit();
	}
	else if(empty($re_pass)){
        header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>Confirm Password is required</div></center>&$user_data");
	    exit();
	}
	else if($pass !== $re_pass){
        header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>The confirmation password does not match</div></center>&$user_data");
	    exit();
	}
else if (strlen($pass)<=7){
	header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>Password is atleast 8 digits</div></center>&$user_data");
	    exit();
	}
	else if(!preg_match("#[A-Z]+#",$pass)) {
		header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>Password must contain 1 Uppercase</div></center>&$user_data");
	    exit();
	}
	else if(!preg_match("#[a-z]+#",$pass)){
		header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>Password must contain 1 Lowercase</div></center>&$user_data");
	    exit();
	}
	else if(!preg_match("#[0-9]+#",$pass)){
		header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>Password must contain Number</div></center>&$user_data");
	    exit();
	}
	elseif(!preg_match("#[\W]+#",$pass))  {
		header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>Password must contain Special Character</div></center>&$user_data");
	    exit();
	}

	else {

	    $sql = "SELECT * FROM users WHERE username='$uname'";
		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) <1) {
			header("Location: change_pass.php?error=center><div style='color:red; margin-bottom:10px;'>No Username Found!</div></center>&$user_data");
	        exit();
		} else {

			$sql3="INSERT INTO acts (id,username,activity,time) VALUES ('', '$uname','$activity','$currentDate')";
            $sql2 = "UPDATE `users` SET `password`='$pass' WHERE `username`='$uname'";
			
            $result2 = mysqli_query($conn, $sql2);
			$result3 = mysqli_query($conn, $sql3);
			
           if ($result2&&$result3) {
           	 header("Location: change_pass.php?success=<center><div style='color:green; margin-bottom:20px;'>Your password has been updated successfully!</div></center>");
			
	         exit();
           }else {
	            	header("Location: change_pass.php?error=<center><div style='color:red; margin-bottom:10px;'>Unknown error occurred</div></center>&$user_data");
		    exit();
           }
		}
	}
}
else {
	header("Location: change_pass.php");
	exit();
}
?>	