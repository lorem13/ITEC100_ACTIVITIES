<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Change Password</title>
</head>

<style>
body{
	margin: 0;
	padding: 0;
	background-image: url('images/bg.jpg');
	background-size: auto;
	background-position: center;
	font-family: 'Poppins', sans-serif;
}
.boxer{
	width: 420px;
	height: 400px;
	background: #7cbcd9;
	color: white;
	top: 50%;
	left: 50%;
	position: absolute;
	transform: translate(-50%, -50%);
	box-sizing: border-box;
	border-radius: 15px;
	padding: 30px 30px;
}
.boxer h2{
	margin: 0;
	padding: 0 0 20px;
	margin-top: 10px;
	text-align: center;
	font-size: 22px;
	color: white;
}
.boxer p{
	margin: 0;
	padding: 0;
	font-weight: bold;
}
.boxer input{
	width: 100%;
	margin-bottom: 20px;
}
.boxer input[type="text"], input[type="password"]{
	border: none;
	border-bottom: 1px solid #fff;
	background: transparent;
	outline: none;
	height: 40px;
	color: white;
	font-size: 16px;	
}
.boxer input[type="submit"]{
	border: none;
	outline: none;
	height: 40px;
	background: #42b2e3;
	color: #fff;
	font-size: 18px;
	border border-radius: 20px;
}
.boxer input[type="submit"]:hover{
	background: #008CBA;
}
</style>

<body>
<div class="boxer">
     <form action="update_pass.php" method="post">
     <h2>FORGOT PASSWORD</h2>

     	<?php if (isset($_GET['error'])) { ?>
     	<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

          <?php if (isset($_GET['success'])) { ?>
          <p class="success"><?php echo $_GET['success']; ?></p>
          <?php } ?>

          <?php if (isset($_GET['uname'])) { ?>
               <input type="text" 
                      name="username" 
                      placeholder="Username"
                      value="<?php echo $_GET['uname']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="uname" 
                      placeholder="Username"><br>
          <?php }?>

	     	<input type="password" 
	                 name="password" 
	                 placeholder="Password"><br>
        
	          <input type="password" 
	                 name="re_password" 
	                 placeholder=" Confirm Password"><br>

		<center><a href="index.php" class="ca">Already have an account?</a></center><br>
     	<input type="submit" value="Update Password">
     </form>
</div>
</body>
</html>


