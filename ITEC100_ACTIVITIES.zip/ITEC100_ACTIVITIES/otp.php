<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>OTP</title>
</head>

<style>
body{
	margin: 0;
	padding: 0;
	background-image: url('images/bg.jpg');
	background-size: auto;
	background-position: center;
	font-family: 'Poppins', sans-serif;
}
.boxer{
	width: 420px;
	height: 250px;
	background: #7cbcd9;
	color: white;
	top: 50%;
	left: 50%;
	position: absolute;
	transform: translate(-50%, -50%);
	box-sizing: border-box;
	border-radius: 15px;
	padding: 30px 30px;
}
.boxer h1{
	margin: 0;
	padding: 0 0 20px;
	text-align: center;
}
.boxer input{
	width: 100%;
	margin-bottom: 20px;
}
.boxer input[type="text"]{
	border: none;
	border-bottom: 1px solid #fff;
	background: transparent;
	outline: none;
	height: 40px;
	color: black;
	font-size: 16px;	
}
.boxer input[type="submit"]{
	border: none;
	outline: none;
	height: 40px;
	background: #42b2e3;
	color: #fff;
	font-size: 18px;
	border border-radius: 20px;
}
.boxer input[type="submit"]:hover{
	background: #008CBA;
}
</style>

<body>
<form action="otp1.php" method="post">
	<div class="boxer">
		<h1>Enter</h1>
		
          <?php if (isset($_GET['num1'])) { ?>
               <input type="text" 
                      name="num1" 
                      placeholder="Username"
                      value="<?php echo $_GET['num1']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="num1" 
                      placeholder="OTP"><br>
          <?php }?>
			<input type="submit" value="Send">	
	<?php 
?> 
	</div>
</form>
</body>
</html>
