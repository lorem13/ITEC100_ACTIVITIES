<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['username'])) {
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Admin Home</title>
</head>

<style>
body{
	margin: 0;
	padding: 0;
	background-image: url('images/bg.jpg');
	background-size: auto;
	background-position: center;
	font-family: 'Poppins', sans-serif;
}
.boxer{
	width: 500px;
	height: 200px;
	background: #7cbcd9;
	color: white;
	top: 50%;
	left: 50%;
	position: absolute;
	transform: translate(-50%, -50%);
	box-sizing: border-box;
	border-radius: 15px;
	padding: 30px 30px;
}
.boxer h1{
    margin: 0 auto;
    text-align: center;
    margin-left: 10px;
    color: green;
}
</style>

<body>
	<div class="boxer">
	<h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
	<center><button type="submit" style="margin-top: 30px; margin-left:3px; background-color:#34e1eb;"><a href="admin_display.php" >View Activity</a> </button><br><br><br>
	<a href="logout.php">Logout</a></center>	
	</div>
</body>
</html>

<?php 
} else {
    header("Location: admin_display.php");
    exit();
}
?>   

