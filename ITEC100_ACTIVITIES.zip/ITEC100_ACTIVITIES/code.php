<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>OTP USERNAME</title>
</head>

<style>
body{
	margin: 0;
	padding: 0;
	background-image: url('images/bg.jpg');
	background-size: auto;
	background-position: center;
	font-family: 'Poppins', sans-serif;
}
.boxer{
	width: 420px;
	height: 230px;
	background: #7cbcd9;
	color: white;
	top: 50%;
	left: 50%;
	position: absolute;
	transform: translate(-50%, -50%);
	box-sizing: border-box;
	border-radius: 15px;
	padding: 30px 30px;}
.pik{
	width: 100px;
	height: 100px;
	border-radius: 50%;
	position: absolute;
	top: -50px;
	left: calc(50% - 50px);
}
.boxer h2{
	margin: 0;
	padding: 0 0 20px;
	margin-top: 10px;
	text-align: center;
	font-size: 22px;
	color: white;
}
.boxer p {
	margin: 0;
	padding: 0;
	font-weight: bold;
}
.boxer input{
	width: 100%;
	margin-bottom: 20px;
}
.boxer input[type="text"], input[type="password"]{
	border: none;
	border-bottom: 1px solid #fff;
	background: transparent;
	outline: none;
	height: 40px;
	color: black;
	font-size: 16px;	
}
.boxer input[type="submit"]{
	border: none;
	outline: none;
	height: 40px;
	background: #42b2e3;
	color: #fff;
	font-size: 18px;
	border border-radius: 20px;
}
.boxer input[type="submit"]:hover{
	background: #008CBA;
}
</style>

<body>
<form action="code1.php" method="post">
	<div class="boxer">
		<h2>ONE TIME PASSWORD</h2>
			
          <?php if (isset($_GET['uname'])) { ?>
               <input type="text" 
                      name="username" 
                      placeholder="Username"
                      value="<?php echo $_GET['uname']; ?>"><br>
          <?php } else { ?>
               <input type="text" 
                      name="uname" 
                      placeholder="Username"><br>
          <?php } ?>
			<input type="submit" value="Send">
	<?php 
?>
	</div>
</form>
</body>
</html>